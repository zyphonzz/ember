import os, json, colorama
with open("apps.json", "r", encoding="utf-8") as f:
    data = json.load(f)
apps = data["applications"]
print("""
▄▄▄ .• ▌ ▄ ·. ▄▄▄▄· ▄▄▄ .▄▄▄  
▀▄.▀··██ ▐███▪▐█ ▀█▪▀▄.▀·▀▄ █·  local
▐▀▀▪▄▐█ ▌▐▌▐█·▐█▀▀█▄▐▀▀▪▄▐▀▀▄   
▐█▄▄▌██ ██▌▐█▌██▄▪▐█▐█▄▄▌▐█•█▌
 ▀▀▀ ▀▀  █▪▀▀▀·▀▀▀▀  ▀▀▀ .▀  ▀  
------------------------------------------------------------------------------------------------------
v0.1 Indev

""")
os_choice = input("os? (1 = linux, 2 = windows): ").strip()
if os_choice not in ("1", "2"):
    print("]")
    exit()
os_name = "linux" if os_choice == "1" else "windows"
print(f"\generating ember for {os_name}...\n")
output_dir = "ember_local_" + os_name
os.makedirs(output_dir, exist_ok=True)

def safe_filename(name):
    return "".join(c for c in name if c.isalnum() or c in " -_").rstrip()

for app in apps:
    name = app["name"]
    url = app["link"]
    tags = app["tags"]

    for tag in tags:
        category_dir = os.path.join(output_dir, safe_filename(tag.lower()))
        os.makedirs(category_dir, exist_ok=True)

        filename = safe_filename(name)
        filepath = os.path.join(category_dir, f"{filename}.desktop" if os_choice == "1" else f"{filename}.url")

        if os_choice == "1":
            desktop_entry = f"""[Desktop Entry]
Name={name}
Comment={app["description"]}
Exec=xdg-open {url}
Icon=utilities-terminal
Terminal=false
Type=Application
Categories=Utility;
"""
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(desktop_entry)

        else:
            shortcut = f"""[InternetShortcut]
URL={url}
"""
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(shortcut)

print(f"ember generated in: {output_dir}")